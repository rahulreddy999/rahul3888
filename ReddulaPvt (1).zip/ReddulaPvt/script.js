document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("formID");
    form.addEventListener("submit", function (event) {
      event.preventDefault(); 
  
      const formData = new FormData(form);
  
      const formDataObject = {};
      formData.forEach(function (value, key) {
        formDataObject[key] = value;
      });
  
      console.log(formDataObject);
  
      form.reset();
    });
  });
  